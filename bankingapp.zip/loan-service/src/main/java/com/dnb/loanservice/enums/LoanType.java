package com.dnb.loanservice.enums;

public enum LoanType {
	LOAN, CREDIT
}
