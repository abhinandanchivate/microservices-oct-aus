package com.dnb.accountservice.dto;

import lombok.Data;

@Data
public class AmountRequest {
    private long amount;
}
