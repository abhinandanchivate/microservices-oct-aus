package com.javatechie.saga.commons.event;

public enum PaymentStatus {

    PAYMENT_COMPLETED,PAYMENT_FAILED
}
